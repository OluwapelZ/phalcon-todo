<?php

namespace App\Validation;

/**
 * Class ValidationConstants
 * @author Adeyemi Olaoye <yemi@cottacush.com>
 * @package App\Validation
 */
class ValidationConstants
{

}
