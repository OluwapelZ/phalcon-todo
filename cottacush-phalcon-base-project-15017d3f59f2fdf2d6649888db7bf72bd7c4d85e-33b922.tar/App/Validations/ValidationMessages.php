<?php

namespace App\Validation;

use PhalconUtils\Validation\ValidationMessages as PhalconUtilsValidationMessages;

/**
 * Class ValidationMessages
 * @author Adeyemi Olaoye <yemi@cottacush.com>
 * @package App\Validation
 */
class ValidationMessages extends PhalconUtilsValidationMessages
{

}
