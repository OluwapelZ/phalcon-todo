<?php
/**
 * Created by PhpStorm.
 * User: oluwapelumi.olaoye
 * Date: 1/28/18
 * Time: 9:22 PM
 */

use Phalcon\Mvc\Micro\Collection as MicroCollection;

$user = new MicroCollection();