<?php

namespace App\Constants;

use PhalconUtils\Constants\ResponseCodes as PhalconUtilsResponseCodes;

/**
 * Class ResponseCodes
 * @author Adeyemi Olaoye <yemi@cottacush.com>
 * @package App\Library
 */
class ResponseCodes extends PhalconUtilsResponseCodes
{

}
