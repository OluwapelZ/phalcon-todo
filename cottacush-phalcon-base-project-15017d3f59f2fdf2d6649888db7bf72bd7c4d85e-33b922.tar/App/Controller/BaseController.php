<?php
/**
 * Created by PhpStorm.
 * User: oluwapelumi.olaoye
 * Date: 1/29/18
 * Time: 3:37 PM
 */

namespace App\Controller;


use Codeception\Module\Phalcon;
use Codeception\Module\Phalcon\Mvc\Controller;

class BaseController extends Controller implements IJSend
{

}