#!/bin/bash

php vendor/bin/codecept run $1 --debug