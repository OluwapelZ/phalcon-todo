<?php

include_once dirname(__FILE__) . '/../public/index.php';

include_once '_support/CommonTests.php';
